export const renderLogin = async (req, res) => {
  res.render("auth/login", { title: "Login", error: null });
};
