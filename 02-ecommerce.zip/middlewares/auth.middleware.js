export const isAdmin = (req, res, next) => {
  if (req.session.userId && req.session.userRole === "admin") {
    return next();
  }
  return res.redirect("/admin/login");
};
