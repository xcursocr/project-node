import express from "express";
import session from "express-session";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import dotenv from "dotenv";
import ejsMate from "ejs-mate";
import { sequelize } from "./config/db.js";
import SequelizeStore from "connect-session-sequelize";

import authRoutes from "./routes/auth.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import storeRoutes from "./routes/store.routes.js";

dotenv.config();

const app = express();
const __dirname = dirname(fileURLToPath(import.meta.url));

const SessionStore = SequelizeStore(session.Store);
const sessionStore = new SessionStore({ db: sequelize });

app.engine("ejs", ejsMate);
app.set("view engine", "ejs");
app.set("views", join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join(__dirname, "public")));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
  }),
);

sessionStore.sync(); //crea la tabla sessions

// Rutas
app.use("/auth", authRoutes);
app.use("/admin", adminRoutes);
app.use(storeRoutes);

export default app;
