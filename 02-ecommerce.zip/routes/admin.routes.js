import express from "express";
import { isAdmin } from "../middlewares/auth.middleware.js";

const router = express.Router();

// Dashboard protegido
router.get("/dashboard", isAdmin, (req, res) => {
  res.render("admin/dashboard");
});

export default router;
