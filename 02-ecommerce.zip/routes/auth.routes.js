import express from "express";
import { renderLogin } from "../controllers/auth/auth.controller.js";

const router = express.Router();

// Login
router.get("/login", renderLogin);
// router.post('/login', login);

// Logout
// router.get('/logout', logout);

export default router;
