import express from "express";
import {
  renderIndex,
  renderProducts,
  renderProfile,
} from "../controllers/store/store.controller.js";

const router = express.Router();

// Store
router.get("/", renderIndex);
router.get("/profile", renderProfile);
router.get("/products", renderProducts);

export default router;
