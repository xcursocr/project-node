import express from "express";
import {
  renderLogin,
  login,
  logout,
  renderRegister,
  register,
} from "../controllers/auth/auth.controller.js";
import { validarLogin, validarRegister } from "../validators/auth.validator.js";
import {
  redirectIfAuth,
  routeProtected,
} from "../middlewares/auth.middleware.js";

const router = express.Router();

// Login
router.get("/login", redirectIfAuth, renderLogin);
router.post("/login", validarLogin, login);

// Register
router.get("/register", redirectIfAuth, renderRegister);
router.post("/register", validarRegister, register);

// Logout
router.get("/logout", routeProtected, logout);

export default router;
