import express from "express";
import { isAdmin, routeProtected } from "../middlewares/auth.middleware.js";
import { listProducts } from "../controllers/admin/product.controller.js";

const router = express.Router();

router.get("/products", routeProtected, isAdmin, listProducts);

// Dashboard protegido
router.get("/dashboard", isAdmin, (req, res) => {
  res.render("admin/dashboard", { title: "Panel de administracion" });
});

export default router;
