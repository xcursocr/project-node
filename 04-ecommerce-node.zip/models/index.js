import { User } from "../models/user.model.js";
import { Category } from "../models/category.model.js";
import { Product } from "../models/product.model.js";
import { Image } from "../models/images.model.js";

// relations
Category.hasMany(Product, { foreignKey: "categoryId", as: "products" });
Product.belongsTo(Category, { foreignKey: "categoryId", as: "category" });

Product.hasMany(Image, { foreignKey: "productId", as: "images" });
Image.belongsTo(Product, { foreignKey: "productId", as: "product" });

export { User, Category, Product, Image };
