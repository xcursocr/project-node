import express from "express";
import session from "express-session";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import dotenv from "dotenv";
import ejsMate from "ejs-mate";
import { sequelize } from "./config/db.js";
import SequelizeStore from "connect-session-sequelize";
import flash from "connect-flash";

import authRoutes from "./routes/auth.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import storeRoutes from "./routes/store.routes.js";

dotenv.config();

const app = express();
const __dirname = dirname(fileURLToPath(import.meta.url));

const SessionStore = SequelizeStore(session.Store);
const sessionStore = new SessionStore({ db: sequelize });

app.engine("ejs", ejsMate);
app.set("view engine", "ejs");
app.set("views", join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join(__dirname, "public")));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: { maxAge: 1000 * 60 * 60 * 2 }, // 2h
  }),
);

sessionStore.sync(); //crea la tabla sessions

app.use(flash());
app.use((req, res, next) => {
  // Asignamos Variables globales
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.old = req.session.old || {};
  res.locals.user = req.session.user || null;
  res.locals.isAuth = !!req.session.user; //(!!) en JavaScript se usa para convertir un valor en un booleano
  res.locals.isAdmin = !!req.session.user?.isAdmin; //(!!) en JavaScript se usa para convertir un valor en un booleano

  // Limpiamos Sessiones
  delete req.session.old; //old
  delete req.session.flash; // flash
  next();
});

// Rutas
app.use("/auth", authRoutes);
app.use("/admin", adminRoutes);
app.use(storeRoutes);

export default app;
