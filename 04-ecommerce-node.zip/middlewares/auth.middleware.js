export const routeProtected = (req, res, next) => {
  if (!req.session.user) {
    return res.redirect("/auth/login");
  }
  next();
};

export const isAdmin = (req, res, next) => {
  if (!req.session.user?.isAdmin) {
    return res.redirect("/auth/login");
  }
  next();
};

export const redirectIfAuth = (req, res, next) => {
  if (req.session.user) {
    return res.redirect("/"); // Redirigir a la página principal
  }
  next(); // Si no está autenticado, continuar con la solicitud normal
};
