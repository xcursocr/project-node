// middlewares/validaciones.js
import { body } from "express-validator";

export const validarLogin = [
  body("email").isEmail().withMessage("Correo electrónico inválido"),
  body("email").notEmpty().withMessage("El correo es obligatorio"),
  body("password").notEmpty().withMessage("La contraseña es obligatoria"),
];
export const validarRegister = [
  body("name").notEmpty().withMessage("El nombre es obligatorio"),
  body("email").isEmail().withMessage("Correo electrónico inválido"),
  body("email").notEmpty().withMessage("El correo es obligatorio"),
  body("password").notEmpty().withMessage("La contraseña es obligatoria"),
];
