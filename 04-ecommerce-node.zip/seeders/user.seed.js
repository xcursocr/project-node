import { faker } from "@faker-js/faker";
import bcrypt from "bcryptjs";
import { User } from "../models/user.model.js";

export const seedUser = async () => {
  const passwordHash = await bcrypt.hash("admin123", 10);

  await User.create({
    name: "Admin",
    email: "admin@admin.com",
    password: passwordHash,
    isAdmin: true,
  });

  for (let i = 0; i < 5; i++) {
    await User.create({
      name: faker.person.fullName(),
      email: faker.internet.email(),
      password: passwordHash,
      isAdmin: false,
    });
  }

  console.log("✔️  Usuarios generados");
};
