import { faker } from "@faker-js/faker";
import { Category } from "../models/category.model.js";

export const seedCategory = async () => {
  const category = [
    "Básculas de piso",
    "Balanzas industriales",
    "Pesaje móvil",
    "Pesas patrón",
  ];

  for (const name of category) {
    await Category.create({
      name,
      description: faker.commerce.productDescription(),
    });
  }

  console.log("✔ Categorías generadas");
};
