import { sequelize } from "../config/db.js";
import { Category, Product, Image, User } from "../models/index.js"; //realaciones
import { seedUser } from "./user.seed.js";
import { seedCategory } from "./category.seed.js";
import { seedProduct } from "./product.seed.js";

const runSeeders = async () => {
  try {
    await sequelize.sync({ force: true });
    console.log("✏️  Base de datos reiniciada");

    await seedUser();
    await seedCategory();
    await seedProduct();

    console.log("✅ Seed completo");
    process.exit();
  } catch (error) {
    console.error("Error al ejecutar seeds", error);
    process.exit(1);
  }
};

runSeeders();
