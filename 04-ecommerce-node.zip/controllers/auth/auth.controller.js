import { User } from "../../models/index.js";
import bcrypt from "bcryptjs";
import { validationResult } from "express-validator";

export const renderLogin = async (req, res) => {
  res.render("auth/login", { title: "Login" });
};

export const renderRegister = async (req, res) => {
  if (!req.session.user) {
    res.render("auth/register", { title: "Registrarse" });
  }
};

export const login = async (req, res) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    req.flash("error", errors.array());
    req.session.old = req.body;
    return req.session.save(() => {
      res.redirect("/auth/login");
    });
  }

  const { email, password } = req.body;

  const user = await User.findOne({ where: { email: email } });

  if (!user) {
    req.flash("error", [{ msg: "EMAIL: Credenciales incorrectas" }]);
    req.session.old = req.body;
    return req.session.save(res.redirect("/auth/login"));
  }

  const match = await bcrypt.compare(password, user.password);

  if (!match) {
    req.flash("error", [{ msg: "PASSWORD: Credenciales incorrectas" }]);
    req.session.old = req.body;
    return req.session.save(res.redirect("/auth/login"));
  }

  // guarda la session
  req.session.user = {
    id: user.id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin,
  };

  res.redirect(user.isAdmin ? "/admin/dashboard" : "/");
};

export const register = async (req, res) => {
  const { name, email, password } = req.body;

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    req.flash("error", errors.array());
    req.session.old = req.body;
    return req.session.save(() => {
      res.redirect("/auth/register");
    });
  }

  const hashPassword = await bcrypt.hash(password, 10);

  await User.create({
    name,
    email,
    password: hashPassword,
    isAdmin: false,
  });

  res.redirect("/auth/login");
};

export const logout = async (req, res) => {
  req.session.destroy(() => res.redirect("/auth/login"));
};
