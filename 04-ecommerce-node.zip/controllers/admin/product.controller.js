import { Product, Category, Image } from "../../models/index.js";

export const listProducts = async (req, res) => {
  const page = parseInt(req.query.page) || parseInt(1);
  const limitPage = 10;
  const offset = (page - 1) * limitPage;

  const countProducts = await Product.count(); // Sin filtros

  const { rows: products } = await Product.findAndCountAll({
    // where: { isActive: true }, // Criterios de búsqueda
    include: [
      { model: Category, as: "category" },
      { model: Image, as: "images" },
    ],
    limit: limitPage,
    offset: offset,
    order: [["createdAt", "DESC"]],
  });

  const totalPages = Math.ceil(countProducts / limitPage);

  res.render("admin/products/index", {
    title: "Productos",
    products,
    page,
    totalPages,
    error: [],
    success: [],
  });
};
