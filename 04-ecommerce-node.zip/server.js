import app from "./app.js";
import { sequelize } from "./config/db.js";

const PORT = process.env.PORT || 3001;

const main = async () => {
  try {
    await sequelize.sync({ alter: true });
    console.log("✅ Base de datos conectada");
    app.listen(PORT, () =>
      console.log(`🚀 Servidor en http://localhost:${PORT}`),
    );
  } catch (error) {
    console.log("❌ Error al iniciar el servidor", error);
  }
};

main();
