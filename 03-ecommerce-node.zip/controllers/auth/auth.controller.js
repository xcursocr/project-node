import { User } from "../../models/user.model.js";
import bcrypt from "bcryptjs";

export const renderLogin = async (req, res) => {
  res.render("auth/login", { title: "Login", error: null });
};

export const login = async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ where: { email: email } });

  if (!user || user.role !== "admin") {
    return res.render("/auth/login", { error: "Credenciales invalidas" });
  }

  const match = await bcrypt.compare(password, user.password);

  if (!match) {
    return res.render("/auth/login", { error: "Credenciales invalidas" });
  }

  req.session.userId = user.id;
  req.session.userRole = user.role;

  res.redirect("/auth/dashboard");
};

export const logout = async (req, res) => {
  req.session.destroy(() => res.redirect("/auth/login"));
};
