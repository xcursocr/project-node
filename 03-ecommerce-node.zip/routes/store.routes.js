import express from "express";

const router = express.Router();

// Store
router.get("/", (req, res) => {
  res.render("store/index", { title: "Home Page" });
});

export default router;
