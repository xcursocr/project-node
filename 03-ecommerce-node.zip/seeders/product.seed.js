import { faker } from "@faker-js/faker";
import { Product } from "../models/product.model.js";
import { Category } from "../models/category.model.js";
import { Image } from "../models/images.model.js";

export const seedProduct = async () => {
  const categories = await Category.findAll();

  for (let i = 0; i < 20; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)];

    const product = await Product.create({
      name: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      price: faker.commerce.price({ min: 100, max: 1000, dec: 2 }),
      stock: faker.number.int({ min: 1, max: 50 }),
      categoryId: category.id,
    });

    // genera entre 1 y 3 imagenes por product

    const numImgs = faker.number.int({ min: 1, max: 3 });

    for (let j = 0; j < numImgs; j++) {
      await Image.create({
        url: `/uploads/fake-${faker.number.int(9999)}.jpg`,
        productId: product.id,
      });
    }

    console.log("✔ Productos con imágenes generados");
  }
};
