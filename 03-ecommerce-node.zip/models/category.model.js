import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/db.js";

export class Category extends Model {}

Category.init(
  {
    name: DataTypes.STRING,
    description: DataTypes.TEXT,
  },
  { sequelize, modelName: "category" },
);
