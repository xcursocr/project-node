import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/db.js";

export class Image extends Model {}

Image.init(
  {
    url: DataTypes.STRING,
  },
  { sequelize, modelName: "image" },
);
